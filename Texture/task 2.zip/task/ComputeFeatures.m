function vect = ComputeFeatures(img,bank)

error('Implement your function here');

end
        
    