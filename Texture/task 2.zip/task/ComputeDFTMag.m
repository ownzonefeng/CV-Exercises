function imageFeatures = ComputeDFTMag(img)

error('Implement your function here');

end