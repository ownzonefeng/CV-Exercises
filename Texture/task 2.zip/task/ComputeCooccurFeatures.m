function cooccurFeats = ComputeCooccurFeatures(img,offset)

% we can see some effects by setting large offset; if we set too small
% offset, the textures will be indistinguishable (you can convince youself)

error('Implement your function here');

end
            