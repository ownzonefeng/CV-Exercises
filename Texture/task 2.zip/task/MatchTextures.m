function label = MatchTextures(testFeatures, templateFeatures)
% NOTE: this function can be used to calculate the distance between test
% and template images using any of the three feature extraction methods

error('Implement your function here');

end